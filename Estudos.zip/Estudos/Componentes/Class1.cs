﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace Componentes
{
    public class Class1
    {
        internal String MetodoSoDOAssemble() {
            return "sou o cabra";
        }

        public String MetodoSoDeTodos()
        {
            return "sou o cabra que preciso de alguem";
        }
    }
}
