﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Funcoes
{
    class Tabuada
    {
        public static void Calcular(int x)
        {
            for (int i = 0; i < 9; i++)
            {
                Console.WriteLine(x + " X " + i + " = " + (x * i));
            }
        }
    }
}
