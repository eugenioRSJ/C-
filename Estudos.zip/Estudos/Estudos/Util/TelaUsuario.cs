﻿using Classes;
using System;
using System.Collections.Generic;
using System.Text;

namespace Estudos.Util
{
    class TelaUsuario
    {
        public static void chamar()
        {
            
            while (true) {
                String mensagem = "Olá usuário \n" +
                              "Escolha uma das opções" +
                              "\n0 - para sair do cadastro" +
                              "\n1 - para Cadastrar Usuario" +
                              "\n2 - para Listar Usuario";

                Console.WriteLine("=========================CADASTRO DE UsuarioS=========================\n\n");
                Console.WriteLine(mensagem);
                int valor = int.Parse(Console.ReadLine());
                if (valor == 0)
                    break;
                else if (valor == 1)
                {
                    var Usuario = new Usuario();

                    Console.WriteLine("Digite o nome do Usuario:");
                    Usuario.Nome = Console.ReadLine();

                    Console.WriteLine("Digite o CPF do Usuario:");
                    Usuario.CPF = Console.ReadLine();

                    Console.WriteLine("Digite o Telefone do Usuario:");
                    Usuario.Telefone = Console.ReadLine();

                    Usuario.Gravar();
                }

                else
                {
                    var Usuarios = new Usuario().Ler();
                    foreach (Base c in Usuarios)
                    {
                        Console.WriteLine(c.Nome);
                    }

                }

            }
        }
    }
}
