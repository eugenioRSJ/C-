﻿using Classes;
using System;
using System.Collections.Generic;
using System.Text;

namespace Estudos.Util
{
    class TelaCliente
    {
        public static void chamar()
        {
            
            while (true) {
                String mensagem = "Olá usuário \n" +
                              "Escolha uma das opções" +
                              "\n0 - para sair do cadastro" +
                              "\n1 - para Cadastrar cliente" +
                              "\n2 - para Listar Cliente";

                Console.WriteLine("=========================CADASTRO DE CLIENTES=========================\n\n");
                Console.WriteLine(mensagem);
                int valor = int.Parse(Console.ReadLine());
                if (valor == 0)
                    break;
                else if (valor == 1)
                {
                    var cliente = new Cliente();

                    Console.WriteLine("Digite o nome do cliente:");
                    cliente.Nome = Console.ReadLine();

                    Console.WriteLine("Digite o CPF do cliente:");
                    cliente.CPF = Console.ReadLine();

                    Console.WriteLine("Digite o Telefone do cliente:");
                    cliente.Telefone = Console.ReadLine();

                    cliente.Gravar();
                }

                else
                {
                    var clientes = new Cliente().Ler();
                    foreach (Base c in clientes)
                    {
                        Console.WriteLine(c.Nome);
                    }

                }

            }
        }
    }
}
