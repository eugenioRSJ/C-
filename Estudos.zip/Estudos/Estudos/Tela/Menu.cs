﻿using Calculo;
using Estudos.Util;
using Funcoes;
using Pastas;
using System;
using System.Collections.Generic;
using System.Text;

namespace Tela
{
    class Menu
    {
        public const int SAIR = 0;
        public const int LER_ARQUIVO = 1;
        public const int EXECUTAR_TABUADA = 2;
        public const int CALCULAR_MEDIA_ALUNO = 3;
        public const int CADASTRAR_CLIENTE = 4;
        public const int CADASTRAR_USUARIO = 5;


        public static void Criar()
        {
            String mensagem = "Bem vindo ao programa \n" +
                              "Escolha uma das opções" +
                              "\n0 - para sair" +
                              "\n1 - para ler arquivo" +
                              "\n2 - para executar a tabuada" +
                              "\n3 - para calcular a média do aluno " +
                              "\n4 - para cadastrar cliente "+
                              "\n5 - para cadastrar usuario ";

            while (true)
            {
                Console.WriteLine(mensagem);
                int valor = int.Parse(Console.ReadLine());
                if (valor == SAIR)
                    break;
                else if (valor == LER_ARQUIVO)
                    Arquivos.Ler("1");
                else if (valor == EXECUTAR_TABUADA)
                {
                    Console.WriteLine("Digite o valor que quer ver  a tabuada");
                    int x = int.Parse(Console.ReadLine());
                    Tabuada.Calcular(x);
                }

                else if (valor == CALCULAR_MEDIA_ALUNO)
                {
                Media.Aluno();
                }

                else if (valor == CADASTRAR_CLIENTE)
                {
                    TelaCliente.chamar();
                }

                else if (valor == CADASTRAR_USUARIO)
                {
                    TelaUsuario.chamar();
                }

                Console.ReadLine();
                Console.Clear();
        }

        }
    }
}
