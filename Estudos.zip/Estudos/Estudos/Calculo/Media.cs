﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Calculo
{
    class Media
    {
        public static void Aluno()
        {
            Console.WriteLine("Digite o nome do aluno");
            String nome = Console.ReadLine();
            int qtdNotas = 3;
            Console.WriteLine("Digite as " + qtdNotas + " do aluno " + nome);

            int totalDeNotas = 0;
            List<int> notas = new List<int>();
            for (int i = 0; i < qtdNotas; i++)
            {
                Console.WriteLine("Digite a nota " + (i + 1));
                int nota = int.Parse(Console.ReadLine());
                totalDeNotas += nota;
                notas.Add(nota);
            }
            float media = totalDeNotas / notas.Count;
            Console.WriteLine("A media do aluno " + nome + " é: " + media);

            foreach (int nota in notas)
            {
                Console.WriteLine("nota: " + nota);
            }
        }
    }
}
