﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace Pastas
{
    class Arquivos
    {
        public static void Ler(String novoArquivo)
        {
            String arquivoCaminho = @"C:\Users\Junior\Desktop\arq" + novoArquivo + ".txt";
            if (File.Exists(arquivoCaminho))
            {
                using (StreamReader arquivo = File.OpenText(arquivoCaminho))
                {
                    String linha;
                    while ((linha = arquivo.ReadLine()) != null)
                    {
                        Console.WriteLine(linha);
                    }
                }
            }
            String arquivoCaminho2 = @"C:\Users\Junior\Desktop\arq" + (novoArquivo + 1) + ".txt";
            if (File.Exists(arquivoCaminho2))
            {
                Ler(arquivoCaminho + 1);
            }
        }
    }
}
