﻿using Classes;
using System;
using System.Collections.Generic;
using System.IO;
using Tela;

namespace Estudos
{
    class Program
    { 

        static void Main(string[] args)
        {
            Menu.Criar();

            
            
        }
    }
} 
