﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Estudos.Classes
{
    class Cachorro : Animal
    {
        public int Idade;   
        public int Idade2{ get; set; }   
        public override void latir()
        {
            Console.WriteLine( "o animal faz auau");
        }
    }
}
