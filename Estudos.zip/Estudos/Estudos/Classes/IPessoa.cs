﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Classes
{
    public interface IPessoa
    {
        void SetNome(String Nome);
        void SetTelefone(String Telefone);
        void SetCPF(String CPF);
        void Gravar();
        
    }
}
