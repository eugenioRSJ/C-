﻿using Classes;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace Estudos
{
    public class Base : IPessoa
    {
        public String Nome { get; set; }
        public String Telefone { get; set; }
        public String CPF { get; set; }

        public Base(String Nome, String Telefone, String CPF)
        {
            this.Nome = Nome;
            this.Telefone = Telefone;
            this.CPF = CPF;
        }
        public Base()
        {

        }
        public void SetNome(String Nome)
        {
            this.Nome = Nome;
        }
        public void SetTelefone(String Telefone)
        {
            this.Telefone = Telefone;
        }
        public void SetCPF(String CPF)
        {
            this.CPF = CPF;
        }

        public void Gravar()
        {
            var dados = this.Ler();
            dados.Add(this);
            String arquivoCaminho = @"C:\Users\Junior\Desktop\estudos\" + diretorio() + ".txt";
            if (File.Exists(arquivoCaminho))
            {
                StreamWriter r = new StreamWriter(arquivoCaminho);
                String conteudo = "Nome;Telefone;cpf;";
                r.WriteLine(conteudo);
                foreach (Base c in dados)
                {
                    var linha = c.Nome + ";" + c.Telefone + ";" + c.CPF + ";";
                    r.WriteLine(linha);
                }
                r.Close();
            }
        }

        public  List<IPessoa> Ler()
        {
            var dados = new List<IPessoa>();
            String arquivoCaminho = @"C:\Users\Junior\Desktop\estudos\" + diretorio() +".txt" ;
            if (File.Exists(arquivoCaminho))
            {
                using (StreamReader arquivo = File.OpenText(arquivoCaminho))
                {
                    String linha;
                    int i = 0;
                    while ((linha = arquivo.ReadLine()) != null)
                    {
                        i++;
                        if (i == 0) continue;
                        var clienteArquivo = linha.Split(';');
                        var b = (IPessoa)Activator.CreateInstance(this.GetType());
                        b.SetNome(clienteArquivo[0]);
                        b.SetTelefone(clienteArquivo[1]);
                        b.SetCPF(clienteArquivo[2]);
                        dados.Add(b);
                    }
                }
            }
            return dados;
        }

        private string diretorio() {
            return this.GetType().Name;
        }
    }
}
