﻿using Estudos;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace Classes
{
    public class Cliente : Base
    {

        public Cliente(String Nome, String Telefone, String CPF) {
            this.Nome = Nome;
            this.Telefone = Telefone;
            this.CPF = CPF;
        }
        public Cliente() {

        }

    }
}
