﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Classes
{
    class Email
    {
        private Email() { }
        private static Email instancia;
        public string Origem; 
        public string Destino;
        public string Corpo;
        public string Titulo;
        public static Email Instancia
        {
            get
            {
                if (instancia == null)
                    instancia = new Email();
                return instancia;
            }
        }

        public static void EnviarEmail()
        {
            Console.WriteLine("Enviando email para "+ instancia.Origem+ " \nCom o titulo: " + instancia.Titulo + "\n Corpo: " + instancia.Corpo);
        }
    }
}
