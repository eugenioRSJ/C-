﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Estudos.Classes
{
    public abstract class Animal
    {
        public string Coleira;
        public string pelo;
        public string olhos;

        public abstract void latir();

        public string Correr()
        {
            return "O animl está correndo";
        }
    }
}
