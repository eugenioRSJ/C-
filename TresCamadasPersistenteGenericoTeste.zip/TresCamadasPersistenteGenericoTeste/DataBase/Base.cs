﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace DataBase
{
    public class Base : IBase
    {

        private string connectionString = ConfigurationManager.AppSettings["SqlConnection"];

        public int key
        {
            get
            {
                foreach(PropertyInfo pi in this.GetType().GetProperties(BindingFlags.Public | BindingFlags.Instance))
                {
                    OpcoesBase pOpcoesBase = (OpcoesBase)pi.GetCustomAttribute(typeof(OpcoesBase));
                    if (pOpcoesBase != null && pOpcoesBase.ChavePrimaria)
                    {
                        return Convert.ToInt32(pi.GetValue(this));
                    }
                }
                return 0;
            }
        }

        public List<IBase> Buscar()
        {
            var list = new List<IBase>();
            using (SqlConnection connection = new SqlConnection(
               connectionString))
            {
                List<string> where = new List<string>();
                string chavePrimaria = string.Empty;
                foreach (PropertyInfo pi in this.GetType().GetProperties(BindingFlags.Public | BindingFlags.Instance))
                {
                    OpcoesBase pOpcoesBase = (OpcoesBase)pi.GetCustomAttribute(typeof(OpcoesBase));
                    if (pOpcoesBase != null)
                    {
                        if (pOpcoesBase.ChavePrimaria)
                        {
                            chavePrimaria = pi.Name;
                        }

                        if (pOpcoesBase.UsarParaBuscar)
                        {
                            var valor = pi.GetValue(this);
                            if (valor != null)
                            {
                                where.Add(pi.Name + " = '" + valor + "'");
                            }
                        }
                    }
                }

                string queryString = "select * from " + this.GetType().Name + "s where " + chavePrimaria + " is not null";
                if (where.Count > 0)
                {
                    queryString += " and " + string.Join(" and ", where.ToArray());
                }

                SqlCommand command = new SqlCommand(queryString, connection);
                command.Connection.Open();

                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    var obj = (IBase)Activator.CreateInstance(this.GetType());
                    setProperty(ref obj, reader);
                    list.Add(obj);
                }
            }
            return list;
        }

        

        public void Salvar()
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {

                List<string> Campos = new List<string>();
                List<string> Valores = new List<string>();
                foreach(PropertyInfo pi in this.GetType().GetProperties(BindingFlags.Instance | BindingFlags.Public))
                {
                    OpcoesBase pOpcoesBase = (OpcoesBase)pi.GetCustomAttribute(typeof(OpcoesBase));
                    if (pOpcoesBase != null && pOpcoesBase.UsarNoBancoDeDados == true && !pOpcoesBase.ChavePrimaria)
                    {

                        if (key == 0)
                        {

                            if (!pOpcoesBase.ChavePrimaria) 
                            {
                                Campos.Add(pi.Name);
                                if(pi.PropertyType.Name =="double")
                                Valores.Add(" " + pi.Name + "= '" + pi.GetValue(this).ToString().Replace(".", "").Replace(",", ".") + "'");
                                Valores.Add("'" + pi.GetValue(this) + "'");
                            }

                        }

                        else
                        {

                            if(!pOpcoesBase.ChavePrimaria)
                                Valores.Add(" " + pi.Name + "= '" + pi.GetValue(this) + "'");
                       
                        }
                        
                    }
                }
                string queryString = string.Empty;

                if (key == 0)
                {
                   queryString = "insert into " + this.GetType().Name + "s (" + string.Join(",", Campos.ToArray()) + ") values(" + string.Join(",", Valores.ToArray()) + ");";
                }
                else
                {
                    queryString = "update " + this.GetType().Name + "s set " + string.Join(",", Valores.ToArray()) + "where id = "+this.key+";";
                }
                SqlCommand command = new SqlCommand(queryString, connection);
                command.Connection.Open();
                command.ExecuteNonQuery();
                command.Connection.Close();
            }
        }

        public void Excluir()
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string queryString = "delete from " + this.GetType().Name + "s where id = " + this.key + ";";
                
                SqlCommand command = new SqlCommand(queryString, connection);
                command.Connection.Open();
                command.ExecuteNonQuery();
                command.Connection.Close();
            }
        }

        public List<IBase> Todos()
        {
            var list = new List<IBase>();
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string queryString = "select * from " + this.GetType().Name + "s;";
                SqlCommand command = new SqlCommand(queryString, connection);
                command.Connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    var obj = (IBase)Activator.CreateInstance(this.GetType());
                    setProperty(ref obj, reader);
                    list.Add(obj);
                }
            }
            return list;
        }

        private void setProperty(ref IBase obj, SqlDataReader reader)
        {
            foreach (PropertyInfo pi in obj.GetType().GetProperties(BindingFlags.Public | BindingFlags.Instance))
            {
                OpcoesBase pOpcoesBase = (OpcoesBase)pi.GetCustomAttribute(typeof(OpcoesBase));
                if (pOpcoesBase != null && pOpcoesBase.UsarNoBancoDeDados )
                {
                    pi.SetValue(obj, reader[pi.Name]);
                }
                
            }
        }

        private string tipoPropriedade(PropertyInfo pi)
        {
            switch (pi.PropertyType.Name)
            {
                case "Int32":
                    return "int";
                case "Int64":
                    return "bigint";
                case "Double":
                    return "decimal(9, 2)";
                case "Single":
                    return "float";
                case "DateTime":
                    return "datetime";
                case "Boolean":
                    return "tinyint";
                default:
                    return "varchar(255)";
            }
        }

        public virtual void CriarTabela()
        {
            using (SqlConnection connection = new SqlConnection(
                         connectionString))
            {
                string chavePrimaria = "";
                List<string> campos = new List<string>();

                foreach (PropertyInfo pi in this.GetType().GetProperties(BindingFlags.Public | BindingFlags.Instance))
                {
                    OpcoesBase pOpcoesBase = (OpcoesBase)pi.GetCustomAttribute(typeof(OpcoesBase));
                    if (pOpcoesBase != null && pOpcoesBase.UsarNoBancoDeDados && !pOpcoesBase.AutoIncrement)
                    {
                        if (pOpcoesBase.ChavePrimaria)
                        {
                            chavePrimaria = pi.Name + " int identity, ";
                        }
                        else
                        {
                            campos.Add(pi.Name + " " + tipoPropriedade(pi) + " ");
                        }
                    }
                }

                string tabelaExiste = "IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[dbo].[" + this.GetType().Name + "s]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)" +
                                    "DROP TABLE " + this.GetType().Name + "s";
                SqlCommand command = new SqlCommand(tabelaExiste, connection);
                command.Connection.Open();
                command.ExecuteNonQuery();

                string queryString = "CREATE TABLE " + this.GetType().Name + "s (";
                queryString += chavePrimaria;
                queryString += string.Join(",", campos.ToArray());
                queryString += "); ";

                command = new SqlCommand(queryString, connection);
                command.ExecuteNonQuery();
            }
        }
    }
}
