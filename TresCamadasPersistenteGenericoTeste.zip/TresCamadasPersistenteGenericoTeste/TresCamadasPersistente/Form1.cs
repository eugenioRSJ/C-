﻿using Business;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TresCamadasPersistente
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void lbCPF_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

            var c= new Carro();
            c.CriarTabela();
            c.Marca = "1";
            c.Nome = "11";
            c.Quantidade = 23;
            c.Valor = 123;
            c.Salvar();
            loadAll();

        }
        private void loadAll()
        {
            Usuario u = new Usuario();
            DgUsuarios.AutoGenerateColumns = false;
            DgUsuarios.DataSource = cbUsuarioBuscar.DataSource =u.Todos();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var usuario = new Usuario();
            if(txtID.Text != "")
            {
                usuario.Id = int.Parse(txtID.Text);
            }
            usuario.Nome = txtNome.Text;
            usuario.Telefone = txtTelefone.Text;
            usuario.CPF = txtCPF.Text;
            usuario.Salvar();
            cbUsusario.DataSource = usuario.Todos();
            MessageBox.Show("Usuário salvo com sucesso");
            LimparCampus();
            DgUsuarios.DataSource = usuario.Todos();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            var endereco = new Endereco();
            endereco.CPF = ((Usuario)cbUsuarioBuscar.SelectedValue).CPF;
            endereco.Logradouro = txtLogadouro.Text;
            endereco.Numero = txtNumero.Text;
            endereco.Cidade = txtCidade.Text;
            endereco.Estado = txtEstado.Text;
            endereco.Salvar();

            MessageBox.Show("Endereco salvo para usuário " + cbUsuarioBuscar.SelectedValue + " com sucesso");
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            var usuario = (Usuario)cbUsuarioBuscar.SelectedValue;
            lbNome.Text = "Nome: " + usuario.Nome;
            lbTelefone.Text = "Teletone: " + usuario.Telefone;
            lbCPF.Text = "CPF: " + usuario.CPF;
            grid.DataSource = usuario.Enderecos;
        }

        private void DgUsuarios_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            Usuario u = (Usuario)DgUsuarios.Rows[e.RowIndex].DataBoundItem;
            txtNome.Text = u.Nome;
            txtTelefone.Text = u.Telefone;
            txtCPF.Text = u.CPF;
            txtID.Text = u.Id.ToString();
            btnGravar.Text = "Alterar";
        }
        private void LimparCampus()
        {
            txtNome.Text = "";
            txtTelefone.Text = "";
            txtCPF.Text = "";
            txtID.Text = String.Empty;
            btnGravar.Text = "Salvar";
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            var resposta = MessageBox.Show("Tem certeza que deseja exclur?","Excluir", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (resposta.Equals(DialogResult.Yes))
            {
                foreach (DataGridViewCell cell in DgUsuarios.SelectedCells)
                {
                    Usuario u = (Usuario)DgUsuarios.Rows[cell.RowIndex].DataBoundItem;
                    u.Excluir();
                }
                foreach (DataGridViewRow row in DgUsuarios.SelectedRows)
                {
                    Usuario u = (Usuario)row.DataBoundItem;
                    u.Excluir();
                }
                loadAll();
            }
             
        }
    }
}
