﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormApllication
{
    public partial class frmImportador : Form
    {
        private String[] lines;
        public frmImportador()
        {
            InitializeComponent();
        }

        private void btnImportar_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < lines.Length; i++)
            {
                var line = lines[i];
                progressBar.Value = (i + 1);
                txtLog.Text +="\n" + line + "-Importado \n q";
                txtLog.Update();
            }

        }

        private void frmImportador_Load(object sender, EventArgs e)
        {
             String FileName = @"C:\Users\Junior\Desktop\estudos\DadosImportar.txt"; 
            using (var StreamRead = File.OpenText(FileName))
            {
                lines = StreamRead.ReadToEnd().Split("\r\n".ToCharArray(), StringSplitOptions.RemoveEmptyEntries);
                progressBar.Maximum = lines.Length;
                progressBar.Minimum = 0;
            }
        }
    }
}
