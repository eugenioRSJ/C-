﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormApllication
{
    public class MdiSingleton
    {
        private MdiSingleton() { }
        private static MDIParentPrincipal instanciaMdiParentePrincipal;
        public static MDIParentPrincipal criar() {
            if (instanciaMdiParentePrincipal == null)
            {
                instanciaMdiParentePrincipal = new MDIParentPrincipal();
                return instanciaMdiParentePrincipal;
            }
            return instanciaMdiParentePrincipal;
        }
    }
}
