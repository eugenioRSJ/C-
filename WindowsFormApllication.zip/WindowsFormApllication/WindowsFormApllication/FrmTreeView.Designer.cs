﻿namespace WindowsFormApllication
{
    partial class FrmTreeView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.TreeNode treeNode1 = new System.Windows.Forms.TreeNode("Nó3");
            System.Windows.Forms.TreeNode treeNode2 = new System.Windows.Forms.TreeNode("Nó4");
            System.Windows.Forms.TreeNode treeNode3 = new System.Windows.Forms.TreeNode("Nó0", new System.Windows.Forms.TreeNode[] {
            treeNode1,
            treeNode2});
            System.Windows.Forms.TreeNode treeNode4 = new System.Windows.Forms.TreeNode("Nó5");
            System.Windows.Forms.TreeNode treeNode5 = new System.Windows.Forms.TreeNode("Nó6");
            System.Windows.Forms.TreeNode treeNode6 = new System.Windows.Forms.TreeNode("Nó1", new System.Windows.Forms.TreeNode[] {
            treeNode4,
            treeNode5});
            System.Windows.Forms.TreeNode treeNode7 = new System.Windows.Forms.TreeNode("Nó9");
            System.Windows.Forms.TreeNode treeNode8 = new System.Windows.Forms.TreeNode("Nó10");
            System.Windows.Forms.TreeNode treeNode9 = new System.Windows.Forms.TreeNode("Nó11");
            System.Windows.Forms.TreeNode treeNode10 = new System.Windows.Forms.TreeNode("Nó7", new System.Windows.Forms.TreeNode[] {
            treeNode7,
            treeNode8,
            treeNode9});
            System.Windows.Forms.TreeNode treeNode11 = new System.Windows.Forms.TreeNode("Nó8");
            System.Windows.Forms.TreeNode treeNode12 = new System.Windows.Forms.TreeNode("Nó2", new System.Windows.Forms.TreeNode[] {
            treeNode10,
            treeNode11});
            this.treeView1 = new System.Windows.Forms.TreeView();
            this.btnChecar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // treeView1
            // 
            this.treeView1.CheckBoxes = true;
            this.treeView1.Location = new System.Drawing.Point(12, 12);
            this.treeView1.Name = "treeView1";
            treeNode1.Name = "Nó3";
            treeNode1.Text = "Nó3";
            treeNode2.Name = "Nó4";
            treeNode2.Text = "Nó4";
            treeNode3.Name = "Nó0";
            treeNode3.Text = "Nó0";
            treeNode4.Name = "Nó5";
            treeNode4.Text = "Nó5";
            treeNode5.Name = "Nó6";
            treeNode5.Text = "Nó6";
            treeNode6.Name = "Nó1";
            treeNode6.Text = "Nó1";
            treeNode7.Name = "Nó9";
            treeNode7.Text = "Nó9";
            treeNode8.Name = "Nó10";
            treeNode8.Text = "Nó10";
            treeNode9.Name = "Nó11";
            treeNode9.Text = "Nó11";
            treeNode10.Name = "Nó7";
            treeNode10.Text = "Nó7";
            treeNode11.Name = "Nó8";
            treeNode11.Text = "Nó8";
            treeNode12.Name = "Nó2";
            treeNode12.Text = "Nó2";
            this.treeView1.Nodes.AddRange(new System.Windows.Forms.TreeNode[] {
            treeNode3,
            treeNode6,
            treeNode12});
            this.treeView1.Size = new System.Drawing.Size(360, 115);
            this.treeView1.TabIndex = 0;
            this.treeView1.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.treeView1_AfterSelect);
            // 
            // btnChecar
            // 
            this.btnChecar.Location = new System.Drawing.Point(296, 158);
            this.btnChecar.Name = "btnChecar";
            this.btnChecar.Size = new System.Drawing.Size(75, 23);
            this.btnChecar.TabIndex = 1;
            this.btnChecar.Text = "Checar";
            this.btnChecar.UseVisualStyleBackColor = true;
            this.btnChecar.Click += new System.EventHandler(this.btnChecar_Click);
            // 
            // FrmTreeView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(400, 203);
            this.Controls.Add(this.btnChecar);
            this.Controls.Add(this.treeView1);
            this.Name = "FrmTreeView";
            this.Text = "FrmTreeView";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TreeView treeView1;
        private System.Windows.Forms.Button btnChecar;
    }
}