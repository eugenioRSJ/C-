﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormApllication
{
    class Estados
    {
        public class Estado
        {

            public int Id { get; set; }
            public string Nome { get; set; }

            public override string ToString()
            {
                return Nome;
            }

            public static List<Estado> Lista()
            {
                var Lista = new List<Estado>();
                var e1 = new Estado();
                e1.Nome = "SP";
                e1.Id = 1;
                Lista.Add(e1);
                var e2 = new Estado();
                e2.Id = 2;
                e2.Nome = "BA";
                Lista.Add(e2);
                return Lista;
            }
        }
    }
}
