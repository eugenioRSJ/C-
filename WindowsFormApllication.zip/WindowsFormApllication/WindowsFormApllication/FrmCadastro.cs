﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormApllication
{
    public partial class FrmCadastro : Form
    {
        public FrmCadastro()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            try
            {
                var nome = txtNome.Text;
                int numero = int.Parse(txtNumero.Text);
                numero += 100;
                MessageBox.Show("Olá " + nome + ", o valor do número mais 100 é de: " + numero);
            }
            catch
            {
                MessageBox.Show("Você não colocou letras no lugar de numeros" + txtNumero.Text);
                txtNumero.Focus();
            }
           
        }

        private void maskedTextBox1_Leave(object sender, EventArgs e)
        {
            if (maskedTextBox1.MaskCompleted)
                MessageBox.Show("Mascara completa");
            else
                MessageBox.Show("Mascara Incompleta");
        }

        private void toolStripTextBox1_Click(object sender, EventArgs e)
        {
            txtBusca.Text = "";
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Estou buscando no banco de dados o" + txtBusca.Text);
        }
    }
}
