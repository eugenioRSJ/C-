﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormApllication
{
    public partial class FrmTabeControl : Form
    {
        public FrmTabeControl()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void FrmTabeControl_Load(object sender, EventArgs e)
        {
            tabControl1.SelectTab("tabPage3");
        }

        private void btnTab1_Click(object sender, EventArgs e)
        {
            tabControl1.SelectTab("tabPage1");
        }

        private void btntab2_Click(object sender, EventArgs e)
        {
            tabControl1.SelectTab("tabPage2");
        }

        private void btnTab3_Click(object sender, EventArgs e)
        {
            tabControl1.SelectTab("tabPage3");
        }
    }
}
