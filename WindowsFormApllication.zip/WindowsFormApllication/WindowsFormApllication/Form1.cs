﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static WindowsFormApllication.Estados;

namespace WindowsFormApllication
{
    
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            txtResultado.Text ="Olá mundo entou em/na " + ((Estado)cmEstados.SelectedItem).Id;
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            var frmShow = new FrmShow();
            frmShow.txtExecucao.Text = txtResultado.Text;
            frmShow.Show();
        }

        private void fechar_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void abrir_Cadastro(object sender, EventArgs e)
        {
            var fr = new FrmCadastro();
            fr.Show();
        }

        private void abrir_Ler_Arquivo(object sender, EventArgs e)
        {
            var fr = new FrmTexto();
            fr.Show();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

            var contextMenu = new ContextMenu();
            contextMenu.MenuItems.Add(new MenuItem("Abrir Ler arquivo", abrir_Ler_Arquivo));
            contextMenu.MenuItems.Add(new MenuItem("Abrir Cadastro", abrir_Cadastro));
            contextMenu.MenuItems.Add(new MenuItem("Fechar", fechar_Click));
            
            notifyIcon.ContextMenu = contextMenu;
            AtualizaHora();
            cmEstados.DataSource = Estado.Lista();
            cmEstados.Text = "Selecione...";
            /****************************************
             * modo mais fácil 
            dataGridView.DataSource = Estado.Lista();
            ******************************************/


            /*****************************************
             * Jeito mais complexo do combo
             * cmEstados.Items.Clear();
            foreach (Estado estado in Estado.Lista())
            { cmEstados.Items.Add(estado); }
            *******************************************/
            /********************************************
             * Maneira complexa dataGrite
            dataGridView.ColumnCount = 2;
            dataGridView.Columns[0].Name = "ID";
            dataGridView.Columns[1].Name = "NOME";

            var rows = new List<string[]>();
            foreach(Estado estado in Estado.Lista())
            {
                string[] row = new string[] { estado.Id.ToString(), estado.Nome };
                rows.Add(row);
            }
            foreach (string[] rowArray in rows)
            {
                dataGridView.Rows.Add(rowArray);
            }
            *********************************************/

            var data = from estado in Estado.Lista()
                       orderby estado.Nome
                       select new
                       {
                           estado.Id,
                           estado.Nome
                       };
            dataGridView.DataSource = data.ToList();
           
        }

        private void AtualizaHora()
        {
            lblHora.Text = "Dia e hora atual: " + DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss");
        }

        private void novoToolStripMenuItem_Click(object sender, EventArgs e)
        {
           new FrmTexto().Show();
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void sobreToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new FrmSobre().Show();
        }

        private void licençaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new FrmLicenca().Show();
        }

        private void doaçãoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new FrmDoacao().Show();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click_1(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            AtualizaHora();
        }

        private void cadastroToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new FrmCadastro().Show();
        }

        private void notifyIcon_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Cliquei no icone");
        }

        private void notifyIcon_DoubleClick(object sender, EventArgs e)
        {
            var frmmTexto = new FrmTexto();
            frmmTexto.MdiParent = MdiSingleton.criar();
            frmmTexto.Show(); 
        }

        private void btnNotificacao_Click(object sender, EventArgs e)
        {
            notifyIcon.ShowBalloonTip(10, "Notificação", txtResultado.Text, ToolTipIcon.Error);
        }

        private void mDIFORMToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new MDIParentPrincipal().Show();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
}
