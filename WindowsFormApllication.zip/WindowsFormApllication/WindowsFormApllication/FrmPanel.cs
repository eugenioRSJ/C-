﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static WindowsFormApllication.Estados;

namespace WindowsFormApllication
{
    public partial class FrmPanel : Form
    {
        public FrmPanel()
        {
            InitializeComponent();
            var data = from estado in Estado.Lista()
                       orderby estado.Nome
                       select new
                       {
                           estado.Id,
                           estado.Nome
                       };
            dataGridView.DataSource = data.ToList();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnAlerta_Click(object sender, EventArgs e)
        {
            MessageBox.Show("O nome digitado é "+ txtNome.Text);
        }

        private void btnMostrar_Click(object sender, EventArgs e)
        {
            if (pnlCadastro.Visible)
            {
                pnlCadastro.Visible = false;
                panel1.Visible = true;
                
            }
            else
            {
                pnlCadastro.Visible = true;
                panel1.Visible = false;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (panel1.Visible)
            {
                pnlCadastro.Visible = true;
                panel1.Visible = false;
            }
            else
            {
                pnlCadastro.Visible = false;
                panel1.Visible = true;
            }
        }
    }
}
