﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormApllication
{
    public partial class FrmTreeView : Form
    {
        public FrmTreeView()
        {
            InitializeComponent();
        }

        private void treeView1_AfterSelect(object sender, TreeViewEventArgs e)
        {
            MessageBox.Show(e.Node.Text);
        }

        private void btnChecar_Click(object sender, EventArgs e)
        {
            MessageBox.Show(LerChecados(treeView1.Nodes[0]));
        }

        private string LerChecados(TreeNode node, String checks= "")
        {
            foreach (TreeNode n in node.Nodes)
            {
                if (n.Checked)
                {
                    checks += n.Text + " ;";
                }
                checks = LerChecados(n, checks);
            }
            return checks;
        }
    }
}
